%% // PUM initialization//
% the file is used to set basic paramters and creat initial matrix  
% ** 2018-08-07 YIHUI ZUO

%% basic paramters
nominal_freq = 50;
T=0.1;
TdF=10;
data_rate_50=1; %case: 1(10),2(25),3(50)
Fs=5e3;
P=11;

%% creat intial matrix
f0 = nominal_freq;

switch data_rate_50
case 1
Fr_50 = 10;
case 2
Fr_50 = 25;
case 3
Fr_50 = 50;
otherwise
display('Non contemplated data reporting rate')
end

Ts=1/Fs;
dF = 1/T;
M = round(T*Fs);
overlap=4*M/5;
kmax = round(f0*T);
k = kmax-4:kmax+12;
Wk = exp(-1i*2*pi*k./M);
NumIters=2;
Fr = Fr_50;
Tr = 1/Fr;
H = M*P;

h_axis = 0:Fs/H:Fs*(H-1)/H; % matrix h_aixs

D = zeros(M,H);%
for k = 0:M-1
    for h = 0:H-1
    esp = k - M*h/H;
    esp = esp*(M-1)/M;
    a = pi*(k-(h/H)*M);
    b = a/M;
    if b == pi || b == 0
        s = 1;
    else
        s = sin(a)/(M*sin(b));
    end
    D(k+1,h+1) = s*exp(-1i*pi*esp);
    end
end

D_funda=D(2:17,51:61);%
D_funda=D_funda'; 
inter_index=[12 17 23 28 83 89 94 100];
D_inter=D(2:17,inter_index);
D_inter=D_inter';
f_fund=h_axis(51:61);
dft_rec=zeros(11,16);
freq=(10:10:160);

for i=1:11
    ff0=f_fund(i);
    dft_rec(i,:) =(0.5*sinc((freq-ff0)*T)+0.25*sinc((freq-ff0-1/T)*T)+0.25*sinc((freq-ff0+1/T)*T))...
    +  (0.5*sinc((-freq+ff0)*T)+0.25*sinc((-freq+ff0-1/T)*T)+0.25*sinc((-freq+ff0+1/T)*T));
end

order = 2;
M=3*M/5;
matrix_f=zeros(M,6,11);%
h=1;
Nh=M/2;
freq=(45:1:55);
for index=1:11
    omega1=2*pi*freq(index)/Fs;
    for i=0:M-1
        n = i - Nh;
        nc = 0;
        facts = factorial(2:-1:0);
        e = exp(1j*n*h*omega1);
        matrix_f(i+1,nc+1:nc+2*order+2,index) = [(((n*Ts).^(order:-1:0)).*e)./facts, (((n*Ts).^(0:1:order)).*e')./fliplr(facts)];
    end
end

matrix_har2=zeros(M,6,11); %
freq=2*(45:1:55);
for index=1:11
    omega1=2*pi*freq(index)/Fs;
    for i=0:M-1
        n = i - Nh;
        nc = 0;
        facts = factorial(2:-1:0);
        e = exp(1j*n*h*omega1);
        matrix_har2(i+1,nc+1:nc+2*order+2,index) = [(((n*Ts).^(order:-1:0)).*e)./facts, (((n*Ts).^(0:1:order)).*e')./fliplr(facts)];
    end
end

matrix_har3=zeros(M,6,11);%
freq=3*(45:1:55);
for index=1:11
    omega1=2*pi*freq(index)/Fs;
    for i=0:M-1
        n = i - Nh;
        nc = 0;
        facts = factorial(2:-1:0);
        e = exp(1j*n*h*omega1);
        matrix_har3(i+1,nc+1:nc+2*order+2,index) = [(((n*Ts).^(order:-1:0)).*e)./facts, (((n*Ts).^(0:1:order)).*e')./fliplr(facts)];
    end
end

M = round(T*Fs);
clear D